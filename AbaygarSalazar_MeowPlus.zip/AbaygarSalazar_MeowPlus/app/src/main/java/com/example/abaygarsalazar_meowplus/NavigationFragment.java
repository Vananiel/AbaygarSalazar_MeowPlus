package com.example.abaygarsalazar_meowplus;

import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;

public class NavigationFragment extends Fragment implements OnMapReadyCallback {

    private GoogleMap map;
    private Button btnSearch, btnClear;
    private EditText editTextLocation;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.nav_fragment, container, false);


        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(NavigationFragment.this);
        btnSearch = (Button) rootView.findViewById(R.id.btnSearch);
        btnClear = (Button) rootView.findViewById(R.id.btnClear);
        editTextLocation = (EditText) rootView.findViewById(R.id.editTextLocation);


        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String location = editTextLocation.getText().toString();

                if (location.length() != 0) {
                    List<Address> addressList = null;
                    if (location != null || !location.equals("")) {
                        Geocoder geocoder = new Geocoder(getActivity().getApplicationContext());
                        try {
                            addressList = geocoder.getFromLocationName(location, 1);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        Address address = addressList.get(0);
                        LatLng latLng = new LatLng(address.getLatitude(), address.getLongitude());
                        map.addMarker(new MarkerOptions().position(latLng).title(location));
                        //map.animateCamera(CameraUpdateFactory.newLatLng(latLng));
                        map.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 16));
                    }

                } else {
                    Toast.makeText(getActivity().getApplicationContext(), "Please input a Location", Toast.LENGTH_LONG).show();
                }
            }
        });
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editTextLocation.setText("");
                map.clear();
            }
        });
        return rootView;


    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        map = googleMap;


        LatLng Goldenpaws = new LatLng(14.288766364532592, 121.11565454453493);
        LatLng Lagunapet = new LatLng(14.280658667985527, 121.12144955133799);
        LatLng oasisclinic = new LatLng(14.279278336613853, 121.12271408395857);
        LatLng RepublicPet = new LatLng(14.233062992970062, 121.14707255287004);
        LatLng Az = new LatLng(14.236089227111005, 121.14441448389248);
        LatLng Pawstar = new LatLng(14.240784320228107, 121.1259447480731);
        LatLng tz = new LatLng(14.242635041416538, 121.14209164314614);
        LatLng th = new LatLng(14.235417979248387, 121.12264026367036);
        LatLng Tien = new LatLng(14.261934869337987, 121.12768281648768);
        LatLng Paps = new LatLng(14.254678892680738, 121.137533782952);
        LatLng South = new LatLng(14.256509022013818, 121.12826406916446);
        map.addMarker(new MarkerOptions().position(Goldenpaws).title("Pet Supplies"));
        map.addMarker(new MarkerOptions().position(Lagunapet).title("Pet Supplies"));
        map.addMarker(new MarkerOptions().position(oasisclinic).title("Pet Clinic"));
        map.addMarker(new MarkerOptions().position(RepublicPet).title("Pet Supplies"));
        map.addMarker(new MarkerOptions().position(Az).title("Pet Supplies"));
        map.addMarker(new MarkerOptions().position(Pawstar).title("Pet Supplies"));
        map.addMarker(new MarkerOptions().position(tz).title("Pet Supplies"));
        map.addMarker(new MarkerOptions().position(th).title("Pet Supplies"));
        map.addMarker(new MarkerOptions().position(Tien).title("Pet Supplies"));
        map.addMarker(new MarkerOptions().position(Paps).title("Pet Supplies"));
        map.addMarker(new MarkerOptions().position(South).title("Pet Supplies"));


    }
}
